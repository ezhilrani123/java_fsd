package AutomateWeb2.Automateweb2;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.Test;

public class NewTest {
	
	@Test(priority = 1)
	  public void register() {
		System.setProperty("webdriver.chrome.driver","D://95//chromedriver.exe");
	      WebDriver wd = new ChromeDriver();
		 
	      wd.manage().window().maximize();
	      wd.get("https://www.amazon.in/");
	      wd.findElement(By.id("nav-link-accountList")).click();
	      wd.findElement(By.id("createAccountSubmit")).click();
	      wd.findElement(By.id("ap_customer_name")).sendKeys("Ezhilrani");
	      //wd.findElement(By.id("ap_phone_number")).sendKeys("1234567890");
	      wd.findElement(By.id("ap_email")).sendKeys("ezhil@gmail.com");
	      wd.findElement(By.id("ap_password")).sendKeys("ezhil12345678");
	     
	   

	     
	  }
	@Test(priority = 2)
	  public void login() {
		  
	      WebDriver wd=new ChromeDriver();
	      wd.manage().window().maximize();
	      wd.get("https://www.amazon.in/");
	      wd.manage().window().maximize();
	      wd.findElement(By.id("nav-link-accountList")).click();
	      wd.findElement(By.id("ap_email")).sendKeys("ezhil@gmail.com");
		  wd.findElement(By.id("continue")).click();
	      wd.findElement(By.id("ap_password")).sendKeys("ezhil12345678");


	  }
	  @Test(priority = 3)
	  public void addToCart() throws InterruptedException {
		  	WebDriver wd=new ChromeDriver();
		  	wd.manage().window().maximize();
	      	wd.get("https://www.amazon.in/");
	      
		    System.out.println(wd.getTitle());
		    System.out.println(wd.getCurrentUrl());
		    wd.findElement(By.id("twotabsearchtextbox")).sendKeys("watch");
		    Thread.sleep(5000);
		    wd.findElement(By.id("nav-search-submit-button")).submit();
		    wd.findElement(By.linkText("Noise ColorFit Pulse Grand Smart Watch with 1.69\" HD Display, 60 Sports Modes, 150 Watch Faces, Spo2 Monitoring, Call Notification, Quick Replies to Text & Calls (Rose Pink)")).click();
	     
}

}
