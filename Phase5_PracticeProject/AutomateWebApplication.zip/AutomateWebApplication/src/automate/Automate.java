package automate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Automate{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //Register the driver
		System.setProperty("webdriver.chrome.driver", "D://95//chromedriver.exe");
		//define the object
		WebDriver driver=new ChromeDriver();
		//maximize the window
		driver.manage().window().maximize();
		driver.get("https://www.shine.com/registration/");
		
		//name
		WebElement name=driver.findElement(By.id("id_name"));
		name.sendKeys("Ezhilrani");
		
		//emai
		WebElement email=driver.findElement(By.id("id_email"));
				email.sendKeys("ezhilranik2000@gmail.com");
		
		//mobile
		WebElement mobile=driver.findElement(By.id("id_cell_phone"));
		mobile.sendKeys("9843516660");
		
		//password
		WebElement password=driver.findElement(By.id("id_password"));
		password.sendKeys("Ezhil@123");
		
		//button
		WebElement register=driver.findElement(By.cssSelector("#registerButton"));
		register.click();
		
		//login button
		WebElement login=driver.findElement(By.cssSelector("#loginContainer"));
		login.click();
		
		 //login email
		 WebElement Email=driver.findElement(By.id("id_email_login"));
		 Email.sendKeys("ezhilranik2000@gmail.com");
		 
		//password
		WebElement Password=driver.findElement(By.id("id_password"));
		Password.sendKeys("Ezhil@123");
		
		//button
		WebElement Login=driver.findElement(By.xpath("//*[@id=\"cndidate_login_widget\"]/form/ul[2]/li[4]/div/button"));
		Login.click();
		
	}



}
