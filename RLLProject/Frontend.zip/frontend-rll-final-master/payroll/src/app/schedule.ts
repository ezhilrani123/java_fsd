export class Schedule {

        empId:number;
        date:string;
        shift:string;
        startingTime:string;
        endTime:string;
        duration:number;
    }
    
