export class Timesheet {
    empId:number;
    date:string;
    inTime:string;
    outTime:string;
    regularTime:string;
    breakTime:string;
    overtimeHours:string;
    totalHours:string;
}
