

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Servlet implementation class Insert
 */
public class Insert extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Insert() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		//Metadata in the config file should be executed
		Metadata md=new MetadataSources(ssr).getMetadataBuilder().build();
		//session factory
		SessionFactory sf=md.getSessionFactoryBuilder().build();
		//session is place where we write the CRUD operations
		Session s=sf.openSession();
		//used to save the crud operations on the db
		Transaction t=s.beginTransaction();
		
		String ename = request.getParameter("name");
		String eemail = request.getParameter("email");
		Employee e=new Employee();
		
		e.setEmpname(ename);
	    e.setEmpemail(eemail);
		s.save(e);
	    t.commit();
	    PrintWriter rd=response.getWriter();
		rd.print("Insertion done");
		
	    s.close();
	    sf.close();
	    
	    
		
		
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
