 function demo(){
    var a="Hello"
    var b="World"
    console.log(a+' '+b)
 }
 demo();

 console.log(12*6)

 console.log('The answer is '+practice(12,6))

 function practice(n1,n2){
    var m=n1/n2;
    var n=n1*n2;
    return (m+n);
 }

 var res1=practice(6,2)
 console.log('Answer is '+res1)

 




