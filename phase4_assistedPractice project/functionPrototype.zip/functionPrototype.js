function Student(name,rollno,birthyear){
    this.name=name;
    this.rollno=rollno;
    this.birthyear=birthyear;

}

Student.prototype.agecalculate=function(){
console.log(this.name+ ' age is '+(2022-this.birthyear))}
console.log(Student.prototype)

let stu1=new Student('Ezhil',21,2000);
console.log(stu1);
stu1.agecalculate();

let stu2=new Student('Rani',21,2001);
console.log(stu2);
stu2.agecalculate();

let stu3=new Student('Mala',21,1998);
console.log(stu2);
stu3.agecalculate();


