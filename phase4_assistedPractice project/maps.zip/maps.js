let emp=new Map();

emp.set("Ezhil","Python");
emp.set("Rani","Java");
emp.set("Sundar",".Net");
emp.set("Akila","UI/UX");
emp.set("Ezhil","BlockChain");

console.log(emp)
console.log(emp.keys())
console.log(emp.values())
console.log(emp.get("Ezhil"))
console.log(emp.get("Ezhi"))
console.log("Employee name Rani is Avaliable? "+emp.has("Rani"))
console.log(emp.has("Kani"))
console.log("delete the element for the key value Akila "+emp.delete("Akila"))
for([k,v] of emp){
    console.log(k,":",v)
}

emp.forEach((v,k)=>{
    console.log(k,":",v)
}
);

emp.clear();
console.log(emp)



class Student
{
    constructor(sid,sname){
        this.sid=sid;
        this.sname=sname;
    }
    studentdetails(){
        document.write(this.sid+" "+this.sname)
    }

}

var r1=new Student(21,"Ezhil")
var r2=new Student(22,"Akila")
console.log(r1)
console.log(r2)

