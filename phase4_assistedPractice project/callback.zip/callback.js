const stuId=(function(){
     var count=0;
     return function(){
    count++;
     return count;
     };
})();
// const stuId=function(){
//     var count=0;
//    count++;
//     return count;
    
// };

console.log("Student Id Details");
console.log("Ezhil: stuid"+stuId());
console.log("Rani: stuid"+stuId());
console.log("Mala: stuid"+stuId());


function call(firstname,lastname,callback){
    console.log('My name is '+firstname+" "+lastname)
    callback(firstname);
}

var greet=function(name){
    console.log('Welcome '+name );
};

call('Mala','Sundar',greet);
call('Kani','Ezhil',greet);
call('Sundar','Akila',greet);