package Group.GroupTest;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class FirstTest {
  @Test(groups= {"sanity"})
  public void  Test4() {
	  System.out.println("This is Test4");
  }
  @Test(groups= {"function","regression","smoke"})
  public void  Test5() {
	  System.out.println("This is Test5");
  }
  @Test(groups= {"sanity","smoke"})
  public void  Test6() {
	  System.out.println("This is Test6");
  }
}
