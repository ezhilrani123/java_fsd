
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Seleniumweb{
	public static void main(String[]args) throws InterruptedException {
		//register chrome driver
		System.setProperty("webdriver.chrome.driver", "D://95//chromedriver.exe");
		//define the object
		WebDriver wb=new ChromeDriver();
		System.out.println(wb);
		//maximize screen
		wb.manage().window().maximize();
		wb.get("https://www.amazon.in");
        wb.findElement(By.linkText("Start here.")).click();
        wb.findElement(By.id("ap_customer_name")).sendKeys("Rani");
        wb.findElement(By.xpath("//*[@id=\"ap_phone_number\"]")).sendKeys("8773456612");
        wb.findElement(By.cssSelector("#ap_email")).sendKeys("rani2@gmail.com");
        
       
        wb.findElement(By.name("password")).sendKeys("Rani@fdhs");  
        wb.findElement(By.className("a-button-input")).click();
        System.out.println(wb.getCurrentUrl());
		System.out.println(wb.getTitle());
		
	}
}

