
import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelFile {
	public static void main(String[] args) throws InterruptedException, IOException {
		//register the chrome driver
		System.setProperty("webdriver.chrome.driver", "D://95//chromedriver.exe");
		//define the object
		WebDriver wb=new ChromeDriver();
		System.out.println(wb);
		//maximize screen
		wb.manage().window().maximize();

		wb.get("https://www.monsterindia.com/seeker/registration");
		wb.findElement(By.xpath("//*[@id=\"file-upload\"]")).sendKeys("D:\\Write_eventm.docx");
		
	
		
	
	}
}

