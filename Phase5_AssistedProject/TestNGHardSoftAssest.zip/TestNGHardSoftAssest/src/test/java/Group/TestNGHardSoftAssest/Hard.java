package Group.TestNGHardSoftAssest;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import static org.testng.Assert.assertEquals;
public class Hard {
	WebDriver wd;
	@BeforeTest
	public void config() {
		System.out.println("Before Test Method ");
		System.setProperty("webdriver.chrome.driver", "D:\\95\\chromedriver.exe");
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		
		
	}
	
	@AfterTest
	public void quit() {
		wd.quit();
	}
	
	
	
	
  @Test
  public void Test1() {
	  wd.get("https://www.google.com");
	  String title=wd.getTitle();
	  String Url=wd.getCurrentUrl();
	  AssertJUnit.assertEquals("Goole",title,"Title not matched");
	 AssertJUnit.assertEquals("https://www.google.com",Url,"Url not matched");
  }
  
  @Test
  public void Test2() {
	  wd.get("https://www.amazon.in");
	  
  }
}
