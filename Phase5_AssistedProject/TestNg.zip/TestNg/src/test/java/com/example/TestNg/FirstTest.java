package com.example.TestNg;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.*;
public class FirstTest {
@Test
public void Test1() {

System.out.println("Test1 is Executed");
}
@Test
public void Test2() {
	System.out.println("Test2 is Executed");

}
@BeforeTest
public void beforeTest() {
	System.out.println("BeforeTest is Executed");
}
@AfterTest
public void AfterTest() {
	System.out.println("AfterTest is Executed");
}
@BeforeMethod
public void beforeMethod() {
	System.out.println("BeforeMethod is Executed");
}
@AfterMethod
public void afterMethod() {
	System.out.println("AfterMethod is Executed");
}
@BeforeClass
public void beforeClass() {
	System.out.println("Beforeclass is Executed");
}
@AfterClass
public void afterClass() {
	System.out.println("AfterClass is Executed");
}
}