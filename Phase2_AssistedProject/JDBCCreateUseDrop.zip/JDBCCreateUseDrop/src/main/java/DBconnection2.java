

import java.sql.*;

public class DBconnection2 {
static Connection con=null;

	public static Connection getConnection(){
		try {
	// load Driver class loader to load driver class in memolry at runtime
		Class.forName("com.mysql.cj.jdbc.Driver");
	String url ="jdbc:mysql://localhost:3306/limi";
	String user ="root";
	String password="12345678";
	con =DriverManager.getConnection(url,user,password);
	}
	catch(Exception e) {
		e.printStackTrace();
	}
		return con;
}}