package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeedbackRestController {
@Autowired
	FeedbackDAO dao;
	
@PostMapping("/insert")
	public Feedback insert(@RequestBody Feedback f) {
		return dao.insert(f);
	}


@PostMapping("/insertall")
public List<Feedback> insertall(@RequestBody List<Feedback> f){
	return dao.insertall(f);
}

}
