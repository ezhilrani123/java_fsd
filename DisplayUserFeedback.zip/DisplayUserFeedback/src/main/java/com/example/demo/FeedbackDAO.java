package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedbackDAO {
//automatically it is going to generate a refernce to the object
	@Autowired
	FeedbackRepo repo;
	
	public Feedback insert(Feedback f) {
		return repo.save(f);
	}
	
	
	public List<Feedback> insertall(List<Feedback> f){
		return repo.saveAll(f);
	}

	
	
}
